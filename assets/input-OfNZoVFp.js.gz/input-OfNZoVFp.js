import{Dt as e,O as t,ct as n,k as r,mt as i,q as a,w as o,yt as s}from"./vue-router-DpP-iWv7.js";import{K as c,O as l}from"./index-D4TT8-Ku.js";import{t as u}from"./AppPageLayout-DuOJLTKk.js";var d=r({__name:`_demo1`,setup(t){let n=s(``);return(t,r)=>{let s=c;return a(),o(s,{modelValue:e(n),"onUpdate:modelValue":r[0]||(r[0]=e=>i(n)?n.value=e:null),placeholder:`请输入内容`},null,8,[`modelValue`])}}}),f=`<script setup lang="ts">
const value = ref('')
<\/script>

<template>
  <KmInput v-model="value" placeholder="请输入内容" />
</template>
`,p=r({__name:`index`,setup(r){return(r,i)=>{let s=l,c=u;return a(),o(c,{navbar:``,"navbar-start-side":`back`},{default:n(()=>[t(s,{code:e(f)},{default:n(()=>[t(d)]),_:1},8,[`code`])]),_:1})}}});export{p as default};